package nlp.intent.mybot;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

import nlp.intent.toolkit.IntentTrainer;

public class mybot {

	public static void main(String[] args) throws IOException {
		Map<String, String> result = new HashMap<String, String>();
		
		// Train the bot to learn categorization.
		IntentTrainer intentCategorizer = new IntentTrainer();		
		intentCategorizer.initialize("fromAccount");
		
		System.out.print(">>>");
		String s = null;

		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));

		while ((s = bufferedReader.readLine()) != null) {
			result = intentCategorizer.categorize(s);
			System.out.println(" # Intent : " + result.get("action"));
			System.out.println(" # Params : " + result.get("args"));
		
			System.out.print(">>>");
		}
		
		bufferedReader.close();

	}

}
