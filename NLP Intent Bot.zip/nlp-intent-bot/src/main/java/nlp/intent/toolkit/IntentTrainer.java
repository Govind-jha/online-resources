package nlp.intent.toolkit;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import opennlp.tools.doccat.DoccatModel;
import opennlp.tools.doccat.DocumentCategorizerME;
import opennlp.tools.doccat.DocumentSample;
import opennlp.tools.namefind.NameFinderME;
import opennlp.tools.namefind.NameSample;
import opennlp.tools.namefind.NameSampleDataStream;
import opennlp.tools.namefind.TokenNameFinderModel;
import opennlp.tools.tokenize.WhitespaceTokenizer;
import opennlp.tools.util.ObjectStream;
import opennlp.tools.util.ObjectStreamUtils;
import opennlp.tools.util.PlainTextByLineStream;
import opennlp.tools.util.Span;
import opennlp.tools.util.TrainingParameters;
import opennlp.tools.util.featuregen.AdaptiveFeatureGenerator;

public class IntentTrainer {

	DocumentCategorizerME categorizer;
	NameFinderME[] nameFinderMEs;
	
	public Map<String, String> categorize(String question) throws IOException {

		final Map<String, String> result = new HashMap<String, String>();
		StringBuilder arguments = new StringBuilder();
		
		if (question != null) {
			double[] outcome = categorizer.categorize(question);
			//System.out.print("action=" + categorizer.getBestCategory(outcome) + " args={ ");
			
			// Intent information.
			result.put("action", categorizer.getBestCategory(outcome));
			
			String[] tokens = WhitespaceTokenizer.INSTANCE.tokenize(question);
			for (NameFinderME nameFinderME : nameFinderMEs) {
				Span[] spans = nameFinderME.find(tokens);
				String[] names = Span.spansToStrings(spans, tokens);
				
				for (int i = 0; i < spans.length; i++) {
					//System.out.print(spans[i].getType() + "=" + names[i] + " ");
					arguments.append(spans[i].getType() + "=" + names[i] + " ");
				}
			}
			
			// Extracted Parameters.
			result.put("args", arguments.toString());
		}
	
		return result;
	}
	
	public DocumentCategorizerME initialize(String slotList) throws IOException{
		
		// The path of the corpus.
		// Array of the arguments to be detected.
		File trainingDirectory = new File("example/weather/train");
		String[] slots = new String[0];

		if (slotList.length() > 0) {
			slots = slotList.split(",");
		}

		if (!trainingDirectory.isDirectory()) {
			throw new IllegalArgumentException(
					"TrainingDirectory is not a directory: " + trainingDirectory.getAbsolutePath());
		}

		// DocumentSample holds a collection of classified documents it's category.
		List<ObjectStream<DocumentSample>> categoryStreams = new ArrayList<ObjectStream<DocumentSample>>();

		
		// Populate the list categoryStreams with the corpus data.
		// removes the extension of the file from it's file name.
		// read the file into object stream object.
		// creates the IntentDocumentSampleStream object.
		ObjectStream<DocumentSample> documentSampleStream = null;
		ObjectStream<String> lineStream = null;
		String intent = null;
		for (File trainingFile : trainingDirectory.listFiles()) {
			intent = trainingFile.getName().replaceFirst("[.][^.]+$", "");
			lineStream = new PlainTextByLineStream(new FileInputStream(trainingFile), "UTF-8");
			documentSampleStream = new IntentDocumentSampleStream(intent, lineStream);
			categoryStreams.add(documentSampleStream);
		}

		// creating one single combined stream for the list categoryStreams
		ObjectStream<DocumentSample> combinedDocumentSampleStream = ObjectStreamUtils
				.createObjectStream(categoryStreams.toArray(new ObjectStream[0]));
		
		System.out.println("------>"+combinedDocumentSampleStream.read().toString());
		
		// Model storing document category.
		DoccatModel doccatModel = DocumentCategorizerME.train("en", combinedDocumentSampleStream, 0, 100);
		combinedDocumentSampleStream.close();

		List<TokenNameFinderModel> tokenNameFinderModels = new ArrayList<TokenNameFinderModel>();
		ObjectStream<NameSample> nameSampleStream = null;
		List<ObjectStream<NameSample>> nameStreams = null;
		for (String slot : slots) {
			nameStreams = new ArrayList<ObjectStream<NameSample>>();
			for (File trainingFile : trainingDirectory.listFiles()) {
				lineStream = new PlainTextByLineStream(new FileInputStream(trainingFile), "UTF-8");
				nameSampleStream = new NameSampleDataStream(lineStream);
				nameStreams.add(nameSampleStream);
			}

			@SuppressWarnings("unchecked")
			ObjectStream<NameSample> combinedNameSampleStream = ObjectStreamUtils
					.createObjectStream(nameStreams.toArray(new ObjectStream[0]));

			// token name finder model is created.
			TokenNameFinderModel tokenNameFinderModel = NameFinderME.train("en", slot, combinedNameSampleStream,
					TrainingParameters.defaultParams(), (AdaptiveFeatureGenerator) null,
					Collections.<String, Object>emptyMap());
			combinedNameSampleStream.close();
			tokenNameFinderModels.add(tokenNameFinderModel);
		}

		categorizer = new DocumentCategorizerME(doccatModel);
		nameFinderMEs = new NameFinderME[tokenNameFinderModels.size()];
		for (int i = 0; i < tokenNameFinderModels.size(); i++) {
			nameFinderMEs[i] = new NameFinderME(tokenNameFinderModels.get(i));
		}

		System.out.println("Training complete. Ready.");
		
		return categorizer;
	}

}
