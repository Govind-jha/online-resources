package com.kumar.JavaDateAndTime;

import java.sql.Time;
import java.time.DayOfWeek;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjuster;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;
import java.util.stream.Collectors;

import org.assertj.core.internal.cglib.core.Local;

public class EventScheduleFeatureImpl implements EventScheduleFeature {
	// Install Timings.
	// Assuming installation is done on passive and than on active.
	private static final int EST_PASSIVE_INSTALL_TIME_HOUR = 23;
	private static final int EST_PASSIVE_INSTALL_TIME_MINUTES = 00;
	private static final int EST_ACTIVE_INSTALL_TIME_HOUR = 16;
	private static final int EST_ACTIVE_INSTALL_TIME_MINUTES = 00;

	// Assuming that the quarter starts on first day of the year.
	private static final LocalDate QUARTER_START_DATE = LocalDate.of(LocalDate.now().getYear(), 1, 1);

	// Fun Event Timings.
	private static final int FUN_EVENT_START_HOUR = 14;
	private static final int FUN_EVENT_START_MINUTES = 00;
	private static final int NEXT_FUN_EVENT_IN_DAYS = 50;

	public List<LocalDateTime> getAllInstallDates() {

		List<LocalDateTime> installDatesList = new ArrayList();
		LocalDate startDate = QUARTER_START_DATE;
		LocalDate offset = startDate.plus(1, ChronoUnit.YEARS);

		LocalDate firstSundayOfMonth = startDate.with(TemporalAdjusters.firstDayOfMonth())
				.with(TemporalAdjusters.nextOrSame(DayOfWeek.SUNDAY));

		while (firstSundayOfMonth.isBefore(offset)) {
			// Monthly install @ 11PM EST
			installDatesList.add(createPassiveInstallDateTimeObject(firstSundayOfMonth));
			// Monthly install @ 4PM EST on the next day.
			installDatesList.add(createActiveInstallDateTimeObject(firstSundayOfMonth));

			firstSundayOfMonth = getNextFirstSundayOfMonth(firstSundayOfMonth);
		}

		return installDatesList;
	}

	private LocalDate getNextFirstSundayOfMonth(LocalDate firstSundayOfMonth) {
		return LocalDate.now().withMonth(firstSundayOfMonth.getMonthValue()).withYear(firstSundayOfMonth.getYear())
				.with(TemporalAdjusters.firstDayOfNextMonth()).with(TemporalAdjusters.nextOrSame(DayOfWeek.SUNDAY));
	}

	private LocalDateTime createPassiveInstallDateTimeObject(LocalDate firstSundayOfMonth) {
		return LocalDateTime
				.of(firstSundayOfMonth,
						LocalTime.now(ZoneId.of(TimeZone.getTimeZone("EST").toZoneId().toString()))
								.withHour(EST_PASSIVE_INSTALL_TIME_HOUR).withMinute(EST_PASSIVE_INSTALL_TIME_MINUTES))
				.withSecond(00).withNano(00);
	}

	private LocalDateTime createActiveInstallDateTimeObject(LocalDate firstSundayOfMonth) {
		return LocalDateTime
				.of(firstSundayOfMonth.plus(1, ChronoUnit.DAYS), LocalTime.now(ZoneId.of("America/New_York"))
						.withHour(EST_ACTIVE_INSTALL_TIME_HOUR).withMinute(EST_ACTIVE_INSTALL_TIME_MINUTES))
				.withSecond(00).withNano(00);
	}

	public List<LocalDate> getAllBirthday() {

		final List<LocalDate> birthdayDatesList = new ArrayList<LocalDate>();
		AssociateSet.getResultSet().stream().map(emp -> birthdayDatesList.add(emp.getDob()))
				.collect(Collectors.toList());

		return birthdayDatesList;
	}

	public List<LocalDateTime> getAllFunEventDates() {

		List<LocalDateTime> funEventDatesList = new ArrayList<LocalDateTime>();
		LocalDate offset = QUARTER_START_DATE.plus(1, ChronoUnit.YEARS);
		List<LocalDateTime> installDatesList = getAllInstallDates();

		LocalDate funEventDate = QUARTER_START_DATE.plus(NEXT_FUN_EVENT_IN_DAYS, ChronoUnit.DAYS);

		while (funEventDate.isBefore(offset)) {
			funEventDate = validateAndScheduleFunEvent(installDatesList, funEventDate);

			funEventDatesList.add(createFunEventDateTimeObject(funEventDate));
			funEventDate = getNextFunEventDate(funEventDate);
		}

		return funEventDatesList;
	}

	private LocalDate getNextFunEventDate(LocalDate funEventDate) {
		return funEventDate.plus(50, ChronoUnit.DAYS);
	}

	private LocalDateTime createFunEventDateTimeObject(LocalDate funEventDate) {
		return LocalDateTime.of(funEventDate, LocalTime.of(FUN_EVENT_START_HOUR, FUN_EVENT_START_MINUTES));
	}

	private LocalDate validateAndScheduleFunEvent(List<LocalDateTime> installDatesList, LocalDate funEventDate) {
		LocalDate rescheduledDate = funEventDate;
		List<LocalDate> installDates = new ArrayList<LocalDate>();

		installDatesList.stream()
				.map(dateTime -> installDates
						.add(LocalDate.of(dateTime.getYear(), dateTime.getMonth(), dateTime.getDayOfMonth())))
				.collect(Collectors.toList());

		while (rescheduledDate.getDayOfWeek().equals(DayOfWeek.SUNDAY) || installDates.contains(rescheduledDate)) {
			rescheduledDate = rescheduledDate.plus(1, ChronoUnit.DAYS).withMonth(rescheduledDate.getMonthValue())
					.withYear(rescheduledDate.getYear());
		}

		return rescheduledDate;
	}

	// Assuming that only the first day information is required,
	// as the return value is a LocalDateTime object and not a list.
	public LocalDateTime getInstallDateOfMonth(Month monthVal) {
		List<LocalDateTime> installDatesList = getAllInstallDates();

		/*
		 * If both the install dates and time is required.
		 * 
		 * return installDatesList.stream() .filter(installDateTime ->
		 * installDateTime.getMonth() == monthVal)
		 * .collect(Collectors.toList());
		 */

		for (LocalDateTime installDateTime : installDatesList) {
			if (installDateTime.getMonth() == monthVal) {
				return installDateTime;
			}
		}

		// No null pointer exception ^_^.
		return LocalDateTime.MAX;
	}

	public Time getInstallTimeInEST() {
		LocalTime installTimeInEST = LocalTime.now(ZoneId.of("America/New_York"))
				.withHour(EST_PASSIVE_INSTALL_TIME_HOUR).withMinute(EST_PASSIVE_INSTALL_TIME_MINUTES).withSecond(00)
				.withNano(00);

		return Time.valueOf(installTimeInEST);
	}

	public Time getInstallTimeInIST() {
		LocalDateTime installDateTimeInEST = getInstallDateOfMonth(Month.FEBRUARY);

		ZoneId EST = ZoneId.of("America/New_York");
		ZonedDateTime dateAndTimeInEST = ZonedDateTime.of(installDateTimeInEST, EST);

		Instant instant = Instant.now();
		ZoneId systemZone = ZoneId.of("Asia/Kolkata");
		ZoneOffset currentOffsetForMyZone = systemZone.getRules().getOffset(instant);
		ZonedDateTime dateAndTimeInIST = dateAndTimeInEST.withZoneSameInstant(currentOffsetForMyZone);

		return Time.valueOf(dateAndTimeInIST.toLocalTime());
	}

	public LocalDateTime getCodeFreezeDateOfRelease(Month monthVal) {
		// Code freeze happens one week before the release.
		return getInstallDateOfMonth(monthVal).minusWeeks(1);
	}

	public List<Event> getBirthdayEventsOfMonth(Month monthVal) {
		List<Event> birthdayEventsOfMonth = new ArrayList<Event>();
		List<Associate> associates = AssociateSet.getResultSet();

		associates.stream().filter(associate -> associate.getDob().getMonthValue() == monthVal.getValue())
				.map(associate -> birthdayEventsOfMonth.add(createBirthdayEventObject(associate))).collect(Collectors.toList());

		return birthdayEventsOfMonth;
	}

	private Event createBirthdayEventObject(Associate associate) {
		return new Event(associate.getName() + "'s Birthday", (int)(Math.random()*10000),
				associate.getDob().withYear(LocalDate.now().getYear()).with(validateAndScheduleBdayEvent));
	}

	TemporalAdjuster validateAndScheduleBdayEvent = TemporalAdjusters.ofDateAdjuster(localDate -> {
		LocalDate rescheduledDate = localDate;
		List<LocalDateTime> installDatesList = getAllInstallDates();
		List<LocalDate> installDates = new ArrayList<LocalDate>();

		installDatesList.stream()
				.map(dateTime -> installDates
						.add(LocalDate.of(dateTime.getYear(), dateTime.getMonth(), dateTime.getDayOfMonth())))
				.collect(Collectors.toList());

		while (rescheduledDate.getDayOfWeek().equals(DayOfWeek.SUNDAY)
				|| rescheduledDate.getDayOfWeek().equals(DayOfWeek.SATURDAY) || installDates.contains(rescheduledDate)
				|| getAllFunEventDates().contains(rescheduledDate)) {

			rescheduledDate = rescheduledDate.plus(1, ChronoUnit.DAYS).withMonth(rescheduledDate.getMonthValue())
					.withYear(rescheduledDate.getYear());
		}

		return rescheduledDate;
	});

	public LocalDateTime getFunDayOfMonth(Month monthVal) {
		List<LocalDateTime> funEventDatesList = getAllFunEventDates();

		for (LocalDateTime funEventDate : funEventDatesList) {
			if (funEventDate.getMonth() == monthVal) {
				return funEventDate;
			}
		}

		return LocalDateTime.MIN;
	}

	public int getNumberOfEventsForMonth(Month monthVal) {
		int numOfEventsForMonth = 0;

		numOfEventsForMonth = (int) getAllBirthday().stream().filter(bdayDate -> bdayDate.getMonth() == monthVal)
				.count();
		numOfEventsForMonth += (int) getAllFunEventDates().stream().filter(funDay -> funDay.getMonth() == monthVal)
				.count();
		numOfEventsForMonth += (int) getAllInstallDates().stream()
				.filter(installDate -> installDate.getMonth() == monthVal).count();

		return numOfEventsForMonth;
	}

	public List<Event> getEventOfTheDay(String dateVal) {
		List<Event> eventsOftheDay = new ArrayList<>();
		int date = Integer.parseInt(dateVal);
		Month currentMonth = LocalDateTime.now().getMonth();

		getAllBirthday().stream()
				.filter(bdayDate -> bdayDate.getDayOfMonth() == date && bdayDate.getMonth() == currentMonth)
				.map(bdayDate -> eventsOftheDay.add(new Event("BirthDay", (int)(Math.random()*10000), bdayDate))).collect(Collectors.toList());

		getAllFunEventDates().stream()
				.filter(funDay -> funDay.getDayOfMonth() == date && funDay.getMonth() == currentMonth)
				.map(funDay -> eventsOftheDay.add(new Event("Fun Event", (int)(Math.random()*10000), funDay.toLocalDate()))).collect(Collectors.toList());

		getAllInstallDates().stream()
				.filter(installDate -> installDate.getDayOfMonth() == date && installDate.getMonth() == currentMonth)
				.map(installDate -> eventsOftheDay.add(new Event("Install Date", (int)(Math.random()*10000), installDate.toLocalDate()))).collect(Collectors.toList());

		return eventsOftheDay;
	}

}
