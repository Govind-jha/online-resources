package com.kumar.JavaDateAndTime;

import java.time.LocalDate;

public class Associate {

	private String empNum;
	private String name;
	private LocalDate dob;
	
	public Associate(String empNum, String name, LocalDate dob) {
		super();
		this.empNum = empNum;
		this.name = name;
		this.dob = dob;
	}

	public String getEmpNum() {
		return empNum;
	}

	public void setEmpNum(String empNum) {
		this.empNum = empNum;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	@Override
	public String toString() {
		return "Associate [empNum=" + empNum + ", name=" + name + ", dob=" + dob + "]";
	}
		
}
