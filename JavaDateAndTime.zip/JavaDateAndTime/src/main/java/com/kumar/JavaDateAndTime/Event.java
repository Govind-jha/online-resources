package com.kumar.JavaDateAndTime;

import java.time.LocalDate;

public class Event {

	private String eventName;
	private int eventId;
	private LocalDate eventDate;
	
	public Event(String eventName, int eventId, LocalDate eventDate) {
		super();
		this.eventName = eventName;
		this.eventId = eventId;
		this.eventDate = eventDate;
	}
	
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public int getEventId() {
		return eventId;
	}
	public void setEventId(int eventId) {
		this.eventId = eventId;
	}
	public LocalDate getEventDate() {
		return eventDate;
	}
	public void setEventDate(LocalDate eventDate) {
		this.eventDate = eventDate;
	}

	@Override
	public String toString() {
		return "Event [eventName=" + eventName + ", eventId=" + eventId + ", eventDate=" + eventDate + "]";
	}
	
}
