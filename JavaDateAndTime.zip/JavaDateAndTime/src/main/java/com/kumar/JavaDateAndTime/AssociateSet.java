package com.kumar.JavaDateAndTime;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class AssociateSet {
	
	public static List<Associate> getResultSet(){
		
		List<Associate> empList = new ArrayList<Associate>();
		
		empList.add(new Associate("1234", "Govind", LocalDate.of(1995, 8, 21)));
		empList.add(new Associate("2345", "Rahul", LocalDate.of(1995, 5, 8)));
		empList.add(new Associate("3456", "Saurabh", LocalDate.of(1995, 10, 29)));
		empList.add(new Associate("4567", "Kunal", LocalDate.of(1995, 1, 11)));
		empList.add(new Associate("5678", "Badri", LocalDate.of(1995, 6, 02)));
		empList.add(new Associate("8989", "Faizan", LocalDate.of(1995, 2, 02)));
		empList.add(new Associate("6876", "Betty", LocalDate.of(1995, 2, 05)));
		
		return empList;
	}
	
}
