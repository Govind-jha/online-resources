package com.kumar.JavaDateAndTime;

import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.List;

public interface EventScheduleFeature {

	public List<LocalDateTime> getAllInstallDates();
	
	public List<LocalDate> getAllBirthday();
	
	public List<LocalDateTime> getAllFunEventDates();
	
	public LocalDateTime getInstallDateOfMonth(Month monthVal);
	
	public Time getInstallTimeInEST();
	
	public Time getInstallTimeInIST();
	
	public LocalDateTime getCodeFreezeDateOfRelease(Month monthVal);
	
	public List<Event> getBirthdayEventsOfMonth(Month monthVal);
	
	public LocalDateTime getFunDayOfMonth(Month monthVal);
	
	public int getNumberOfEventsForMonth(Month monthVal);
	
	public List<Event> getEventOfTheDay(String dateVal);
	
}
