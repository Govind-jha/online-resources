package com.kumar.JavaDateAndTime;

import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.List;

import junit.framework.Assert;
import junit.framework.TestCase;

public class EventScheduleFeatureImplTest extends TestCase {

	EventScheduleFeatureImpl eventScheduleFeature;

	protected void setUp() throws Exception {
		eventScheduleFeature = new EventScheduleFeatureImpl();
	}

	public void testGetAllInstallDates() {
		List<LocalDateTime> installDatesList = eventScheduleFeature.getAllInstallDates();
		
		Assert.assertNotNull("The install Dates list is null.", installDatesList);
		Assert.assertEquals(installDatesList.size(), 24);
	}

	public void testGetAllBirthday() {
		List<LocalDate> birthdayDatesList = eventScheduleFeature.getAllBirthday();
		
		Assert.assertNotNull("The birthday dates list is null.", birthdayDatesList);
		Assert.assertTrue(birthdayDatesList.contains(LocalDate.of(1995, 8, 21)));
	}

	public void testGetAllFunEventDates() {
		List<LocalDateTime> funEventDatesList = eventScheduleFeature.getAllFunEventDates();
		
		Assert.assertNotNull(funEventDatesList);
		Assert.assertEquals(funEventDatesList.size(), 7);		
	}

	public void testGetInstallDateOfMonth() {		
		LocalDateTime installDateForFeb2017 = eventScheduleFeature.getInstallDateOfMonth(Month.FEBRUARY);
		Assert.assertEquals(LocalDateTime.of(2017, 02, 05, 23, 00), installDateForFeb2017);
	}

	public void testGetInstallTimeInEST() {
		Time installTimeInEST = eventScheduleFeature.getInstallTimeInEST();
		
		Assert.assertEquals(Time.valueOf("23:00:00"), installTimeInEST);
	}

	public void testGetInstallTimeInIST() {
		Time installTimeInEST = eventScheduleFeature.getInstallTimeInIST();
		
		Assert.assertEquals(Time.valueOf("09:30:00"), installTimeInEST);
	}

	public void testGetCodeFreezeDateOfRelease() {
		LocalDateTime codeFreezeDate = eventScheduleFeature.getCodeFreezeDateOfRelease(Month.FEBRUARY);
		Assert.assertNotNull(codeFreezeDate);
		Assert.assertEquals(LocalDateTime.parse("2017-01-29T23:00"), codeFreezeDate);
	}

	public void testGetBirthdayEventsOfMonth() {
		List<Event> birthdayEventOfMonth = eventScheduleFeature.getBirthdayEventsOfMonth(Month.FEBRUARY);
		
		Assert.assertNotNull(birthdayEventOfMonth);
		Assert.assertTrue(birthdayEventOfMonth.size() == 2);
	}

	public void testGetFunDayOfMonth() {
		LocalDateTime funDay = eventScheduleFeature.getFunDayOfMonth(Month.FEBRUARY);
		
		Assert.assertNotNull(funDay);
		Assert.assertEquals(LocalDateTime.parse("2017-02-20T14:00"), funDay);
	}

	public void testGetNumberOfEventsForMonth() {
		int count = eventScheduleFeature.getNumberOfEventsForMonth(Month.JANUARY);
		Assert.assertTrue(count == 3);
	}

	public void testGetEventOfTheDay() {
		List<Event> events = eventScheduleFeature.getEventOfTheDay("08");
		Assert.assertTrue(events.size()==2);
	}

}
